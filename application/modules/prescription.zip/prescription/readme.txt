version 0.0.1
Requires Chikitsa 0.2.9
Compatible upto 0.2.9

1. Print Prescription
