DROP TABLE %db_prefix%email_log;
DROP TABLE %db_prefix%sms_log;
DROP TABLE %db_prefix%alerts;