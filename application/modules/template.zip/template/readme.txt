version 0.0.4
Requires Chikitsa 0.3.0
Compatible upto 0.3.0

0.0.4
1. New Shortcodes added
0.0.1
1. Modify the Print Templates
