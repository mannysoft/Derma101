version 0.0.7
Requires Chikitsa 0.3.8

0.0.1
1. Email Alerts
2. SMS Alerts
3. Alert Templates

0.0.2
1. Alerts Log
2. Optimization
3. Bug Fixes

0.0.3 
1. Send Appointment Reminders

0.0.4
1. Addition of Template ID in URL

0.0.5 
1. Send Dose Reminders
2. Send Birthday Wishes
3. Send Payment Receipt
4. Better Email Options – Send SMTP Emails too

0.0.6
1. Send Appointment Reminders (SMS)
2. Send Dose Reminders (SMS)

0.0.7
1. Send Birthday Wishes to Patients


	