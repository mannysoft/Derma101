version 0.0.5
Requires Chikitsa 0.2.7

0.0.1
1. Manage Items 
2. Manitain Supplier Details
3. Maintain Purchase details
4. Sale 
5. Purchase Report

0.0.2 (Coming Up)
1. Use of COntact View for Supplier
2. Allow to add Patient from Sale View
3. Fetch Price from MRP 

0.0.3
1. Compatible with 0.2.4

0.0.4
1. Bug Fix of Available Stock
2. Some other minor Bug Fixes

0.0.5
1. Bug Fixes

