DELETE FROM %db_prefix%modules WHERE module_name = 'template';
DELETE FROM %db_prefix%navigation_menu WHERE menu_name  = 'receipt_template';